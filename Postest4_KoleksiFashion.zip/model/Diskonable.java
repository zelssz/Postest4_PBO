// Nama  : Zelsya Rizqita Rahmadhini
// NIM   : 2409116022
// KELAS : A 2024

package com.mycompany.koleksifashion.model;

public interface Diskonable {
    double getHargaDasar();

    default double getHargaFinal() {     
        return getHargaDasar();
    }

    default double hitungDiskon(double persen) {
        if (persen <= 0) return 0;
        return getHargaFinal() * (persen / 100.0);
    }
}
