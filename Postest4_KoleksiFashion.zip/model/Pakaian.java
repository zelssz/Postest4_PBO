package com.mycompany.koleksifashion.model;


public class Pakaian extends Item implements Diskonable {
    private String bahan;

    public Pakaian(int id, String nama, String ukuran, String warna,
                   String brand, int tahun, String bahan, double harga) {
        super(id, nama, "Pakaian", ukuran, warna, brand, tahun, harga);
        this.bahan = bahan;
    }

    // POLYMORPHISM (Overloading) – buat objek dengan harga default
    public Pakaian(int id, String nama, String ukuran, String warna,
                   String brand, int tahun, String bahan) {
        this(id, nama, ukuran, warna, brand, tahun, bahan, 100000); // default
    }

    public String getBahan() { return bahan; }
    public void setBahan(String bahan) { this.bahan = bahan; }
    
    public double hitungDiskon() {
        // contoh aturan: bahan katun 10%, lainnya 5%
        return bahan.equalsIgnoreCase("katun") ? 0.10 : 0.05;
    }

    @Override
    public double hitungHargaAkhir() {
        return harga - (harga * hitungDiskon());
    }

    @Override
    public String deskripsiSingkat() {
        return super.deskripsiSingkat() + " | bahan: " + bahan +
               String.format(" | nett: Rp%.0f", hitungHargaAkhir());
    }

    @Override
    public double getHargaDasar() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
