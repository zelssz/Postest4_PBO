package com.mycompany.koleksifashion.model;

public class Aksesoris extends Item implements Diskonable {
    private String material;

    public Aksesoris(int id, String nama, String ukuran, String warna,
                     String brand, int tahun, String material, double harga) {
        super(id, nama, "Aksesoris", ukuran, warna, brand, tahun, harga);
        this.material = material;
    }

    // POLYMORPHISM (Overloading) – harga default
    public Aksesoris(int id, String nama, String ukuran, String warna,
                     String brand, int tahun, String material) {
        this(id, nama, ukuran, warna, brand, tahun, material, 75000);
    }

    public String getMaterial() { return material; }
    public void setMaterial(String material) { this.material = material; }

    public double hitungDiskon() {
        // contoh aturan: material kulit 15%, lain 8%
        return material.equalsIgnoreCase("kulit") ? 0.15 : 0.08;
    }

    @Override
    public double hitungHargaAkhir() {
        double kenaPajak = harga * 1.05;
        return kenaPajak - (kenaPajak * hitungDiskon());
    }

    @Override
    public String deskripsiSingkat() {
        return super.deskripsiSingkat() + " | material: " + material +
               String.format(" | nett: Rp%.0f", hitungHargaAkhir());
    }

    @Override
    public double getHargaDasar() {
        throw new UnsupportedOperationException("Not supported yet.");  
    }

    @Override
    public double getHargaFinal() {
        return Diskonable.super.getHargaFinal();  
    }

    @Override
    public double hitungDiskon(double persen) {
        return Diskonable.super.hitungDiskon(persen);
}
}