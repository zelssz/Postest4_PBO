package com.mycompany.koleksifashion.model;


public abstract class Item {
    protected int id;
    public String nama;
    public String kategori;   // "Pakaian" / "Aksesoris"
    public String ukuran;
    public String warna;
    public String brand;
    public int tahun;
    protected double harga;      // harga dasar

    public Item(int id, String nama, String kategori,
                String ukuran, String warna, String brand,
                int tahun, double harga) {
        this.id = id;
        this.nama = nama;
        this.kategori = kategori;
        this.ukuran = ukuran;
        this.warna = warna;
        this.brand = brand;
        this.tahun = tahun;
        this.harga = harga;
    }

    // ABSTRACTION: kontrak perilaku yang harus diisi oleh subclass
    public abstract double hitungHargaAkhir();

    public int getId() { return id; }
    public String getNama() { return nama; }
    public String getKategori() { return kategori; }
    public String getUkuran() { return ukuran; }
    public String getWarna() { return warna; }
    public String getBrand() { return brand; }
    public int getTahun() { return tahun; }
    public double getHarga() { return harga; }
    public void setHarga(double harga) { this.harga = harga; }

    // POLYMORPHISM (Overriding) – boleh dioverride oleh turunan
    public String deskripsiSingkat() {
        return String.format("[%s] %s - %s/%s (%s) Rp%.0f",
                kategori, nama, ukuran, warna, brand, harga);
    }

    @Override
    public String toString() {
        return deskripsiSingkat();
    }
}
