package com.mycompany.koleksifashion.service;

import com.mycompany.koleksifashion.model.*;
import java.util.*;
import java.util.stream.Collectors;

public class FashionService {
    private final List<Item> items = new ArrayList<>();
    private int seq = 1;

    public FashionService() {
        seed10Items(); 
    }

    // ===================== SEED DATA 10 ITEM =====================
    private void seed10Items() {
        tambah("Jaket Denim",       "Outer",     "L",   "Biru",    "Levi's",   2021);
        tambah("Sneakers Canvas",   "Sepatu",    "42",  "Putih",   "Converse", 2022);
        tambah("Kaos Graphic",      "Atasan",    "L",   "Hitam",   "Uniqlo",   2023);
        tambah("Dress Batik",       "Atasan",    "M",   "Maroon",  "Lokal",    2023);
        tambah("Celana Chino",      "Bawahan",   "32",  "Khaki",   "H&M",      2022);
        tambah("Rok Plisket",       "Bawahan",   "M",   "Cream",   "Zara",     2021);
        tambah("Topi Bucket",       "Aksesoris", "All", "Cream",   "Columbia", 2020);
        tambah("Kemeja Flanel",     "Atasan",    "L",   "Merah",   "Uniqlo",   2021);
        tambah("Hoodie Oversize",   "Outer",     "XL",  "Abu",     "H&M",      2024);
        tambah("Tas Selempang",     "Aksesoris", "All", "Hitam",   "Herschel", 2020);
    }

    public void tambah(String nama, String kategori, String ukuran, String warna,
                       String brand, int tahun) {
        Item obj;
        if (kategori != null && kategori.equalsIgnoreCase("Aksesoris")) {
            obj = new Aksesoris(seq++, nama, ukuran, warna, brand, tahun, "Resin");
        } else if (kategori != null && (kategori.equalsIgnoreCase("Sepatu") || kategori.equalsIgnoreCase("Outer")
                || kategori.equalsIgnoreCase("Atasan") || kategori.equalsIgnoreCase("Bawahan"))) {
            obj = new Pakaian(seq++, nama, ukuran, warna, brand, tahun, "Katun");
        } else {
            obj = new Pakaian(seq++, nama, ukuran, warna, brand, tahun, "Katun");
        }
        items.add(obj);
    }

    public Item cari(int id) {
        return byId(id);
    }
    
    public List<Item> cari(String keyword) {
        String k = keyword.toLowerCase();
        return items.stream().filter(i ->
            i.getNama().toLowerCase().contains(k) ||
            i.getKategori().toLowerCase().contains(k) ||
            i.getBrand().toLowerCase().contains(k)
        ).collect(Collectors.toList());
    }

    public Item byId(int id) {
        for (Item it : items) if (it.getId() == id) return it;
        return null;
    }

    public List<Item> filterKategori(String kategori) {
        if (kategori == null) return List.of();
        String k = kategori.toLowerCase();
        return items.stream()
                .filter(i -> i.getKategori() != null && i.getKategori().toLowerCase().equals(k))
                .collect(Collectors.toList());
    }

    // Ubah data: hanya field yang != null akan diperbarui
    public boolean update(int id, String nama, String kategori, String ukuran,
                          String warna, String brand, Integer tahun) {
        Item it = byId(id);
        if (it == null) return false;

        if (nama != null) it.nama = nama;
        if (kategori != null) it.kategori = kategori;
        if (ukuran != null) it.ukuran = ukuran;
        if (warna != null) it.warna = warna;
        if (brand != null) it.brand = brand;
        if (tahun != null) it.tahun = tahun;

        return true;
    }

    public boolean hapus(int id) {
        Item it = byId(id);
        return it != null && items.remove(it);
    }

    public List<Item> semua() {
        // biar tidak bisa dimodifikasi dari luar
        return Collections.unmodifiableList(items);
    }

    // Tambahan util (opsional)
    public double totalNilaiStok() {
        return items.stream().mapToDouble(Item::hitungHargaAkhir).sum();
    }
}
