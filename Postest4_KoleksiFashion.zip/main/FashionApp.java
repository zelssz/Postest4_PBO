// Nama  : Zelsya Rizqita Rahmadhini
// NIM   : 2409116022
// KELAS : A 2024

package com.mycompany.koleksifashion.main;

import com.mycompany.koleksifashion.model.Item;
import com.mycompany.koleksifashion.service.FashionService;

import java.util.List;
import java.util.Scanner;

public class FashionApp {
    private static final FashionService svc = new FashionService();

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        while (true) {
            clearScreen();
            printBanner();
            printMainMenu();

            System.out.print("Pilih menu [1-7] > ");
            String p = in.nextLine().trim();

            switch (p) {
                case "1" -> { clearScreen(); sectionTitle("TAMBAHKAN KOLEKSI ITEM"); tambahItem(in); pause(in); }
                case "2" -> { clearScreen(); sectionTitle("DAFTAR KOLEKSI"); tampilkanTabel(svc.semua()); pause(in); }
                case "3" -> { clearScreen(); sectionTitle("CARI (ID/NAMA)"); cari(in); pause(in); }
                case "4" -> { clearScreen(); sectionTitle("UBAH Data Koleksi"); ubah(in); pause(in); }
                case "5" -> { clearScreen(); sectionTitle("HAPUS Koleksi"); hapus(in); pause(in); }
                case "6" -> { clearScreen(); sectionTitle("FILTER KOLEKSI"); filterMenu(in); pause(in); }
                case "7" -> { clearScreen(); boxInfo("Terima kasih. Program selesai."); return; }
                default -> { boxInfo("Menu tidak valid. Coba lagi."); pause(in); }
            }
        }
    }

    static void tambahItem(Scanner in) {
        String nama     = inputWajib(in, "Nama");
        String kategori = inputWajib(in, "Kategori");
        String ukuran   = inputWajib(in, "Ukuran");
        String warna    = inputWajib(in, "Warna");
        String brand    = inputWajib(in, "Brand/Desainer");
        int tahun       = inputAngkaNonNegatif(in, "Tahun Koleksi");

        svc.tambah(nama, kategori, ukuran, warna, brand, tahun);
        boxInfo("Item ditambahkan.");
    }

    static void cari(Scanner in) {
        System.out.print("Masukkan ID atau Nama Produk: ");
        String q = in.nextLine().trim();

        List<Item> hasil;
        try {
            int id = Integer.parseInt(q);
            Item one = (Item) svc.cari(id);
            hasil = (one == null) ? List.of() : List.of(one);
        } catch (NumberFormatException e) {
            hasil = (List<Item>) svc.cari(q);
        }

        if (hasil.isEmpty()) boxInfo("Tidak ditemukan.");
        else tampilkanTabel(hasil);
    }

    static void ubah(Scanner in) {
        int id = inputAngkaNonNegatif(in, "Masukkan ID");
        Item it = (Item) svc.byId(id);
        if (it == null) { boxInfo("ID tidak ditemukan."); return; }

        System.out.println("(Biarkan kosong untuk pertahankan nilai lama)");

        System.out.print("Nama [" + it.getNama() + "]: ");
        String nama = keepOrNull(in.nextLine());

        System.out.print("Kategori [" + it.getKategori() + "]: ");
        String kategori = keepOrNull(in.nextLine());

        System.out.print("Ukuran [" + it.getUkuran() + "]: ");
        String ukuran = keepOrNull(in.nextLine());

        System.out.print("Warna [" + it.getWarna() + "]: ");
        String warna = keepOrNull(in.nextLine());

        System.out.print("Brand [" + it.getBrand() + "]: ");
        String brand = keepOrNull(in.nextLine());

        System.out.print("Tahun [" + it.getTahun() + "]: ");
        String v = in.nextLine().trim();
        Integer tahun = v.isEmpty() ? null : parseNonNegIntOrNull(v);

        boolean ok = svc.update(id, nama, kategori, ukuran, warna, brand, tahun);
        boxInfo(ok ? "Item berhasil diperbarui." : "Gagal memperbarui.");
    }

    static void hapus(Scanner in) {
        int id = inputAngkaNonNegatif(in, "Masukkan ID");
        Item it = (Item) svc.byId(id);
        if (it == null) { boxInfo("ID tidak ditemukan."); return; }
        System.out.print("Yakin hapus \"" + it.getNama() + "\"? (y/n): ");
        String y = in.nextLine().trim().toLowerCase();
        boolean ok = y.equals("y") && svc.hapus(id);
        boxInfo(ok ? "Data dihapus." : "Dibatalkan.");
    }

    static void filterMenu(Scanner in) {
        System.out.println();
        System.out.println("+-----------------------------+");
        System.out.println("| 1) Berdasarkan Kategori     |");
        System.out.println("| 2) Kembali                  |");
        System.out.println("+-----------------------------+");
        System.out.print("Pilih [1-2] > ");
        String c = in.nextLine().trim();

        switch (c) {
            case "1" -> {
                String kat = inputWajib(in, "Masukkan Kategori");
                List<Item> out = (List<Item>) svc.filterKategori(kat);
                if (out.isEmpty()) boxInfo("Tidak ada item pada kategori: " + kat);
                else tampilkanTabel(out);
            }
            case "2" -> {}
            default -> boxInfo("Pilihan tidak valid.");
        }
    }

    static void tampilkanTabel(List<Item> data) {
        if (data.isEmpty()) { System.out.println("(kosong)"); return; }

        String[] head = {"ID", "Nama", "Kategori", "Ukuran", "Warna", "Brand", "Tahun"};
        int[] w = new int[head.length];
        for (int i = 0; i < head.length; i++) w[i] = head[i].length();

        int CAP = 28;
        for (Item it : data) {
            w[0] = Math.max(w[0], String.valueOf(it.getId()).length());
            w[1] = Math.max(w[1], it.getNama().length());
            w[2] = Math.max(w[2], it.getKategori().length());
            w[3] = Math.max(w[3], it.getUkuran().length());
            w[4] = Math.max(w[4], it.getWarna().length());
            w[5] = Math.max(w[5], it.getBrand().length());
            w[6] = Math.max(w[6], String.valueOf(it.getTahun()).length());
        }
        for (int i = 0; i < w.length; i++) w[i] = Math.min(w[i], CAP);

        String sep = "+" + repeat("-", w[0]+2) + "+" + repeat("-", w[1]+2) + "+" + repeat("-", w[2]+2)
                   + "+" + repeat("-", w[3]+2) + "+" + repeat("-", w[4]+2) + "+" + repeat("-", w[5]+2)
                   + "+" + repeat("-", w[6]+2) + "+";

        System.out.println(sep);
        System.out.println("| " + pad(head[0], w[0]) + " | " + pad(head[1], w[1]) + " | " +
                           pad(head[2], w[2]) + " | " + pad(head[3], w[3]) + " | " +
                           pad(head[4], w[4]) + " | " + pad(head[5], w[5]) + " | " +
                           pad(head[6], w[6]) + " |");
        System.out.println(sep);

        for (Item it : data) {
            System.out.println("| " + pad(String.valueOf(it.getId()), w[0]) + " | " +
                               pad(it.getNama(), w[1]) + " | " +
                               pad(it.getKategori(), w[2]) + " | " +
                               pad(it.getUkuran(), w[3]) + " | " +
                               pad(it.getWarna(), w[4]) + " | " +
                               pad(it.getBrand(), w[5]) + " | " +
                               pad(String.valueOf(it.getTahun()), w[6]) + " |");
        }
        System.out.println(sep);
    }

    static void printBanner() {
        String title = " MANAJEMEN KOLEKSI FASHION ";
        String line = repeat("=", title.length());
        System.out.println("+" + line + "+");
        System.out.println("|" + title + "|");
        System.out.println("+" + line + "+");
        System.out.println("Kelola koleksi pribadi.\n");
    }

    static void printMainMenu() {
        String[] rows = {
            "1) Tambahkan Koleksi Item",
            "2) Tampilkan Daftar Item",
            "3) Cari (ID/Nama)",
            "4) Ubah Data Koleki",
            "5) Hapus Koleksi",
            "6) Filter Koleksi",
            "7) Keluar dari Program"
        };
        int width = 0;
        for (String r : rows) width = Math.max(width, r.length());
        String top = "+" + repeat("-", width + 2) + "+";
        System.out.println(top);
        for (String r : rows) System.out.println("| " + pad(r, width) + " |");
        System.out.println(top + "\n");
    }

    static void sectionTitle(String text) {
        String line = repeat("-", text.length()+2);
        System.out.println("+" + line + "+");
        System.out.println("| " + text + " |");
        System.out.println("+" + line + "+\n");
    }

    static void boxInfo(String msg) {
        String line = repeat("-", msg.length()+2);
        System.out.println("\n+" + line + "+");
        System.out.println("| " + msg + " |");
        System.out.println("+" + line + "+");
    }

    static void pause(Scanner in) {
        System.out.print("\n(Enter untuk kembali ke menu utama) ");
        in.nextLine();
    }

    static void clearScreen() { System.out.print("\033[H\033[2J"); System.out.flush(); }

    static String pad(String s, int w) {
        if (s.length() > w) return s.substring(0, w);
        StringBuilder sb = new StringBuilder(s);
        while (sb.length() < w) sb.append(' ');
        return sb.toString();
    }

    static String repeat(String s, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(s);
        return sb.toString();
    }

    static String inputWajib(Scanner in, String label) {
        while (true) {
            System.out.print(label + " : ");
            String x = in.nextLine().trim();
            if (!x.isEmpty()) return x;
            boxInfo("Tidak boleh kosong.");
        }
    }

    static int inputAngkaNonNegatif(Scanner in, String label) {
        while (true) {
            System.out.print(label + " : ");
            String x = in.nextLine().trim();
            try {
                int v = Integer.parseInt(x);
                if (v >= 0) return v;
            } catch (NumberFormatException ignored) {}
            boxInfo("Tidak Valid, Harap Masukkan Angka Non-Negatif!");
        }
    }

    static Integer parseNonNegIntOrNull(String s) {
        try { int v = Integer.parseInt(s); return v >= 0 ? v : null; }
        catch (NumberFormatException e) { return null; }
    }

    static String keepOrNull(String s) {
        String v = s.trim();
        return v.isEmpty() ? null : v;
    }
}
